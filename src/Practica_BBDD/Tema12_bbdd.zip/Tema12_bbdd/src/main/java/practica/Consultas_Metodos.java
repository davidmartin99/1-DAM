package practica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Clase que sirve para crear la conexión, crear Statement y ejecutar la consulta así cómo devolver el resultado
 *
 * @author david
 */
public class Consultas_Metodos {

          private Connection conexion;
          private Statement sentencia;

          
          private void conectar() throws SQLException {
                   // Insertamos nuestros datos correspondientes
                   String url = "jdbc:mysql://192.168.80.253:3306/empresa?allowPublicKeyRetrieval=true&useSSL=false&serverTimeZone=UTC";
                   String user = "david4";
                   String password = "David!1234";

                   try {
                            conexion = DriverManager.getConnection(url, user, password);
                   } catch (SQLException e) {
                            System.err.println("Num Error: " + e.getErrorCode());
                            System.err.println("Error en la conexión: " + e.getMessage());
                   }//Fin try-catch
          }//Fin conectar

          
          private void crearSentencia() throws SQLException {
                    sentencia = conexion.createStatement();
          }//Fin crearSentencia

          
          private void cerrarConexion() throws SQLException {
                    if (sentencia != null) {
                              sentencia.close();
                    }
                    if (conexion != null) {
                              conexion.close();
                    }//Fin if
          }//Fin cerrarConexion

          
          public ResultSet ejecutarConsulta(String consulta) throws SQLException {
                    ResultSet resultado = null;
                    try {
                              conectar();
                              crearSentencia();

                              resultado = sentencia.executeQuery(consulta);
                    } catch (SQLException e) {
                              System.err.println("Num Error: "+e.getErrorCode());
                              System.err.println("Error al ejecutar la consulta: " + e.getMessage());
                    }//Fin try-catch
                    return resultado;
          }//Fin ejecutarConsulta

          
          public int ejecutarInstruccion(String instruccion) throws SQLException {
                    int filasAfectadas = 0;
                    try {
                              conectar();
                              crearSentencia();

                              filasAfectadas = sentencia.executeUpdate(instruccion);
                    }catch (SQLException e) {
                             System.err.println("Num Error: "+e.getErrorCode());
                             System.err.println("Error al ejecutar sentencia: "+ e.getMessage());
                    }  finally {
                              cerrarConexion();
                    }//Fin try-catch
                    return filasAfectadas;
          }//Fin ejecutarInstruccion 

         
          
          
          public void imprimirEmpleado(String consultaBuscar) throws SQLException {
                  ResultSet resultadoDatos = null;
                  try {
                           conectar();
                           crearSentencia();

                           resultadoDatos = sentencia.executeQuery(consultaBuscar);

                           if (resultadoDatos.next()) {
                                    // Si se encuentra un empleado lo imprime
                                    int num = 1;
                                    do {
                                             String nombre = resultadoDatos.getString("nombre");
                                             String apellidos = resultadoDatos.getString("apellidos");
                                             String fechaNacimiento = resultadoDatos.getString("fechaNacimiento");
                                             String fechaIngreso = resultadoDatos.getString("fechaIngreso");
                                             String puesto = resultadoDatos.getString("puesto");
                                             double salario = resultadoDatos.getDouble("salario");

                                             // Imprimimos los datos del empleado
                                              System.out.println(num+".");
                                             System.out.println("Nombre: " + nombre);
                                             System.out.println("Apellidos: " + apellidos);
                                             System.out.println("Fecha de Nacimiento: " + fechaNacimiento);
                                             System.out.println("Fecha de Ingreso: " + fechaIngreso);
                                             System.out.println("Puesto: " + puesto);
                                             System.out.println("Salario: " + salario);

                                             num++;
                                    } while (resultadoDatos.next());
                           } else {
                                    System.out.println("Empleado no encontrado");
                           }//Fin if-else
                  } catch (SQLException e) {
                           System.err.println("Num Error: "+e.getErrorCode());
                           System.err.println("Error al ejecutar la consulta: " + e.getMessage());
                  } finally {
                           // Cerrar el ResultSet y la conexión
                           if (resultadoDatos != null) {
                                    try {
                                             resultadoDatos.close();
                                    } catch (SQLException ex) {
                                             System.err.println("Error al cerrar el ResultSet: " + ex.getMessage());
                                    }//Fin try-catch
                           }//Fin if
                           cerrarConexion();
                  }//Fin try-catch
         }//Fin ImprimirEmpleado


}//Fin class
